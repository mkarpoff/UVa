/* UVa problem: 10608
 *
 * Topic: Data structures
 *
 * Level: trivial
 * 
 * Brief problem description: 
 *
 *   Transitivity of friends ie finding interconnected graph segments
 *
 * Solution Summary:
 *
 *   Algorithmic idea, data structures ...
 *
 * Used Resources:
 *
 *   ...
 *
 * I hereby certify that I have produced the following solution myself 
 * using the resources listed above in accordance with the CMPUT 403 
 * collaboration policy.
 *
 * --- Marcus Karpoff
 */

#include <iostream>
#include <matrix>

using namespace std;

const int U = 0;
const int V = 1;

int main() {

	int ntc = 0;
	int n;
	int m;

	cin >> ntc; 
	for (int i = 1; i <= ntc; ++i ) {
		cin >> n >> m;

		matrix<int> adjMat(n,n);

		for(int j = 1; j <= m; ++j ) {
			int t1,t2;
			cin >> t1 >> t2;
			pairs.push_back(tuple<int,int>(t1,t2));
		}
		
		for (auto p:pairs) {
			cout << '(' << get<0>(p) << ", " << get<1>(p) << ')' << endl;
		}
	}

	return 0;
}
									 
